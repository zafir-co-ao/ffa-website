export declare function requestInit(method?: "GET" | "POST" | "PATCH" | "DELETE" | "PUT", body?: string | FormData, contentType?: "application/json"): RequestInit;
