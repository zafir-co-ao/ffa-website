declare const webContentServiceClient: {
    get: (uuid: string, lang: string) => Promise<string>;
};
export default webContentServiceClient;
