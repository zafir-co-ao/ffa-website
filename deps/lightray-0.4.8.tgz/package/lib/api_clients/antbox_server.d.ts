export interface AntboxServer {
    url?: string;
}
declare const antboxServer: AntboxServer;
export declare function configure(url: string): void;
export default antboxServer;
