<script lang="ts" setup>
import { onMounted, computed } from "vue";
import { Node, FOLDER_MIMETYPE, SMART_FOLDER_MIMETYPE } from "antbox";
import MIMETYPES_ICONS from "./mimetypes_icons";
import { formatFileSize } from "./node_helpers";

interface InputDeviceCapabilities {
	sourceCapabilities: { firesTouchEvents: boolean };
}

interface ContentNodeProps {
	node: Node;
	selected: boolean;
}

interface ContentNodeEmits {
	(e: "select", uuid: string): void;
	(e: "open", uuid: string): void;
	(e: "context", payload: { uuid: string; event: MouseEvent }): void;
	(e: "multipleSelect", uuids: string): void;
}

const props = defineProps<ContentNodeProps>();
const emit = defineEmits<ContentNodeEmits>();

const iconId = computed(() => "node-wrapper-inner__" + props.node.uuid);

const icon = MIMETYPES_ICONS[props.node.mimetype] ?? MIMETYPES_ICONS.UNKNOWN_MIMETYPE;
const isFile = ![SMART_FOLDER_MIMETYPE, FOLDER_MIMETYPE].includes(props.node.mimetype);
const fileSize = formatFileSize(props.node.size);

// onMounted(() => {
// 	// document.getElementById(iconId.value).addEventListener("contextmenu", (event) => {
// 	// 	event.preventDefault();
// 	// 	emit("context", { uuid: props.node.uuid, event });
// 	// });
// 	// console.log("oieeee");
// });

function handleClick(event: MouseEvent) {
	const isMobile =
		(event as unknown as InputDeviceCapabilities).sourceCapabilities
			?.firesTouchEvents ?? false;

	if (isMobile) return emit("open", props.node.uuid);

	if (event.shiftKey) return emit("multipleSelect", props.node.uuid);

	emit("select", props.node.uuid);
}
</script>

<template>
	<div>
		<div class="node-wrapper">
			<div
				:id="iconId"
				class="node-wrapper-inner"
				:class="{ 'node-wrapper-inner__selected': selected }"
				@dblclick="emit('open', node.uuid)"
				@click="handleClick"
			>
				<img class="node-icon" draggable="false" :src="icon" />
				<div class="node-title">{{ node.title }}</div>
				<div v-if="isFile" class="node-size">{{ fileSize }}</div>
			</div>
		</div>
	</div>
</template>

<style lang="scss" scoped>
$icon-width: 64px;
$title-width: 84px;
$icon-margin: 8px;

$selected-color: #e3f2fd;

.node-wrapper,
.node-wrapper-inner {
	padding: $icon-margin;
}

.node-wrapper-inner {
	display: flex;
	flex-direction: column;
	align-items: center;
	border-radius: 4px;

	position: relative;
}

.node-wrapper-inner__selected {
	background-color: $selected-color;
	outline-offset: -4px;
	outline: 4px solid transparent;
}

.node-wrapper-inner:hover {
	cursor: pointer;
}

.node-icon {
	width: $icon-width;
	height: $icon-width;

	background-size: contain;
}

.node-title {
	box-sizing: border-box;

	line-height: 1.5em;

	margin-top: 4px;

	width: $title-width;
	max-height: 3em;
	overflow: hidden;
	text-overflow: ellipsis;
	text-align: center;
}

.node-size {
	color: darkslategray;
	text-align: center;
}
</style>
