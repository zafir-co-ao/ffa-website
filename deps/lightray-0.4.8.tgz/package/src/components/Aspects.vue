<script lang="ts" setup>
import { computed, onMounted, reactive, ref } from "vue";
import { Aspect } from "antbox";
import { Toast, useToast } from "./toasts";

import AspectIcon from "./AspectIcon.vue";
import AspectDetailsPanel from "./AspectDetailsPanel.vue";
import LoadingSpinner from "./LoadingSpinner.vue";
import { AspectServiceClient } from "./types";

const DEFAULT_EXCEPTION_SUMMARY = "Ocorreu um erro";
const DEFAULT_SUCCESS_SUMMARY = "Operação concluída com sucesso";

interface AspectsState {
	aspects: Aspect[];
	selectedUuid?: string;
	loading: boolean;
}

interface AspectsProps {
	aspectServiceClient: AspectServiceClient;
}

const { aspectServiceClient } = defineProps<AspectsProps>();

let toast: Toast;

const state = reactive<AspectsState>({ aspects: [], loading: false });

const aspectsDivRef = ref<HTMLDivElement>();
const fileUploadRef = ref<HTMLInputElement>();
const updateFileUploadRef = ref<HTMLDivElement>();
const aspectDetailsRef = ref();

const selectedAspect = computed(
	() => state.aspects.find((el) => el.uuid === state.selectedUuid) as Aspect,
);

const isSelected = (uuid: string) => state.selectedUuid === uuid;
const handleSelect = (uuid: string) => (state.selectedUuid = uuid);

onMounted(() => {
	toast = useToast(aspectsDivRef.value!!);

	// Hook para posicionar os details
	const offset = aspectsDivRef.value?.offsetTop;

	aspectDetailsRef.value.style.height = `calc(100vh - ${offset}px)`;

	listAspects(state);
});

async function handleFileUpload() {
	if (fileUploadRef.value?.files?.[0]) {
		await uploadAspectAndExecuteAction(
			fileUploadRef.value.files[0],
			(aspect: Aspect) => aspectServiceClient.create(aspect),
		);

		fileUploadRef.value.value = "";
		await listAspects(state);
	}
}

async function handleUpdateFileUpload() {
	if (fileUploadRef.value?.files?.[0]) {
		await uploadAspectAndExecuteAction(
			fileUploadRef.value.files[0],
			(aspect: Aspect) => aspectServiceClient.update(state.selectedUuid!!, aspect),
		);

		fileUploadRef.value.value = "";
		listAspects(state);
	}
}

async function uploadAspectAndExecuteAction(
	file: File,
	postUploadCb: (a: Aspect) => Promise<void>,
) {
	if (file) {
		handleInfo("O ficheiro está a ser carregado, aguarde por favor...");

		try {
			const fileText = await file.text();
			const aspect = JSON.parse(fileText);

			await postUploadCb(aspect);

			handleSuccess("Ficheiro carregado com sucesso");
		} catch (err) {
			handleException(err as Error, "O carregamento não foi bem sucedido");
		}
	}
}

async function listAspects(state: AspectsState) {
	try {
		state.loading = true;
		const result = await aspectServiceClient.list();
		state.aspects = result;
	} catch (err) {
		handleException(err as Error, "Ocorreu um erro inesperado");
		console.error(err);
	} finally {
		state.loading = false;
	}
}

async function handleDownload(uuid: string) {
	try {
		const aspect = state.aspects.find((el) => el.uuid === uuid) as Aspect;
		const file = new Blob([JSON.stringify(aspect)]);

		const anchor = document.createElement("a");
		anchor.href = URL.createObjectURL(file);
		anchor.download = aspect.title.concat(".json");
		anchor.type = "application/json";
		anchor.target = "_blank";
		anchor.click();
	} catch (err) {
		handleException(err as Error, "A descarga do ficheiro não foi bem sucedida");
	}
}

async function deleteAspect(state: AspectsState) {
	try {
		await aspectServiceClient.delete(state.selectedUuid!!);
		handleSuccess("Aspecto removido com sucesso");
		listAspects(state);
	} catch (err) {
		handleException(err as Error, "Não foi possível apagar o aspecto");
	}
}

function handleException(
	err: Error,
	detail: string,
	summary = DEFAULT_EXCEPTION_SUMMARY,
): void {
	toast.add({ detail, summary, severity: "error" });
	console.error(err);
}

function handleSuccess(detail: string, summary = DEFAULT_SUCCESS_SUMMARY): void {
	toast.add({ detail, summary, severity: "success" });
}

function handleInfo(detail: string, summary?: string): void {
	toast.add({ detail, summary, severity: "info" });
}
</script>

<template>
	<div ref="aspectsDivRef" class="aspects">
		<div class="aspects__main">
			<div class="aspects__content">
				<div class="mb-6 d-flex align-items-baseline">
					<button
						type="button"
						class="btn btn-primary m-1"
						@click="fileUploadRef?.click()"
					>
						Carregar Aspecto
					</button>

					<button
						type="button"
						class="btn btn-warning m-1"
						@click="updateFileUploadRef?.click()"
						:disabled="!state.selectedUuid"
					>
						Actualizar Aspecto
					</button>

					<button
						type="button"
						class="btn btn-danger m-1"
						@click="deleteAspect(state)"
						:disabled="!state.selectedUuid"
					>
						Apagar Aspecto
					</button>
				</div>

				<div class="aspects__header">
					<div class="fw-bold fs-6 mt-5 mb-5">Aspectos</div>
				</div>

				<div v-if="!state.loading" class="aspects__nodes">
					<aspect-icon
						v-for="aspect in state.aspects"
						:key="aspect.uuid"
						:uuid="aspect.uuid"
						:title="aspect.title"
						:selected="isSelected(aspect.uuid)"
						@download="handleDownload"
						@select="handleSelect"
					/>
				</div>
				<loading-spinner v-else />
			</div>

			<div ref="aspectDetailsRef" class="aspect__details d-none d-lg-block">
				<aspect-details-panel v-if="selectedAspect" :aspect="selectedAspect" />
			</div>
		</div>
	</div>

	<div class="d-none">
		<input
			ref="fileUploadRef"
			type="file"
			accept="application/json"
			@change="handleFileUpload"
		/>
		<input
			ref="updateFileUploadRef"
			type="file"
			accept="application/json"
			@change="handleUpdateFileUpload"
		/>
	</div>
</template>

<style lang="scss" scoped>
$icon-width: 96px;
$icon-margin: 12px;

.aspects {
	font-size: 0.8em;
}
.aspects__main {
	display: flex;
	flex-wrap: nowrap;
}

.aspect__details {
	box-sizing: border-box;
	flex: 0 0 256px;
}

.aspects__content {
	flex: 1 1 auto;

	padding: 1rem;
}

.aspects__nodes {
	display: flex;
	flex-wrap: wrap;
}
</style>
