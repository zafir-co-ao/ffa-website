<template>
    <h1 class="text-center m-4">Hello Light</h1>
</template>