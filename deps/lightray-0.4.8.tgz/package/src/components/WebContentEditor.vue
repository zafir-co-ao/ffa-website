<script lang="ts">
import HtmlEditor from "./HtmlEditor.vue";

import { ref, watch } from "vue";
import { WebContent } from "antbox";
</script>

<script lang="ts" setup>
interface WebContentProps {
	content: WebContent;
}

const props = defineProps<WebContentProps>();
const emit = defineEmits<{ (e: "save", content: WebContent): void }>();

const curcontent = ref("");
const curlang = ref("pt");
const content = ref<Record<string, string>>();

watch(
	() => props.content,
	() => {
		content.value = props.content as unknown as Record<string, string>;
		curcontent.value = content.value.pt;
		curlang.value = "pt";
	},
);

function changeLanguage(lang: string) {
	if (content.value) {
		if (!content.value[lang]) {
			content.value[lang] = "";
		}

		content.value[curlang.value] = curcontent.value;
		curcontent.value = content.value[lang];
		curlang.value = lang;
	}
}

/*
function save() {
	if (content.value) {
		content.value[curlang.value] = curcontent.value;
	}

	emit("save", content.value as unknown as WebContent);
}
*/
</script>

<template>
	<div class="mb-2 mt-4">
		<button
			role="button"
			class="btn btn-sm"
			:class="{
				'btn-primary': curlang === 'pt',
				'btn-secondary': curlang !== 'pt',
			}"
			@click="changeLanguage('pt')"
		>
			Português
		</button>
		&nbsp;
		<button
			role="button"
			class="btn btn-sm"
			:class="{
				'btn-primary': curlang === 'en',
				'btn-secondary': curlang !== 'en',
			}"
			@click="changeLanguage('en')"
		>
			Inglês
		</button>
	</div>
	<html-editor v-model="curcontent" />
</template>
