export default {
	"application/folder": "/images/lightray/mimetypes/folder.svg",
	"application/json": "/images/lightray/mimetypes/text-css.svg",
	"application/smartfolder": "/images/lightray/mimetypes/folder-templates.svg",

	"application/wps-office.xlsx": "/images/lightray/mimetypes/application-vnd.ms-excel.svg",

	"application/pdf": "/images/lightray/mimetypes/application-pdf.svg",

	"application/zip": "/images/lightray/mimetypes/application-x-zip.svg",

	"image/gif": "/images/lightray/mimetypes/image-x-generic.svg",
	"image/jpg": "/images/lightray/mimetypes/image-x-generic.svg",
	"image/jpeg": "/images/lightray/mimetypes/image-x-generic.svg",
	"image/png": "/images/lightray/mimetypes/image-x-generic.svg",
	"image/svg+xml": "/images/lightray/mimetypes/image-svg+xml.svg",

	"text/html": "/images/lightray/mimetypes/text-html.svg",
	"text/css": "/images/lightray/mimetypes/text-css.svg",
	"text/plain": "/images/lightray/mimetypes/text-plain.svg",
	"text/x-go": "/images/lightray/mimetypes/text-x-go.svg",
	"text/x-java": "/images/lightray/mimetypes/text-x-java.svg",
	"text/javascript": "/images/lightray/mimetypes/text-x-javascript.svg",
	UNKNOWN_MIMETYPE: "/images/lightray/mimetypes/unknown_file.svg",
} as Record<string, string>;
