<script lang="ts" setup>
import { computed, onMounted, ref, watch } from "vue";
import { AspectProperty } from "antbox";

const props = defineProps<{ property: AspectProperty; modelValue: any }>();
const emit = defineEmits<{ (e: "update:modelValue", value: any): void }>();

const multichoiceModel = ref<any[]>([]);
const fieldId = "aspect-".concat(props.property.name);

const isSingleChoice = computed(
	() =>
		(props.property.validationList ? true : false) &&
		!props.property.type.endsWith("[]"),
);

const isMultichoice = computed(() => {
	return (
		props.property.type.endsWith("[]") &&
		(props.property.validationList ? true : false)
	);
});

const isBoolean = computed(() => props.property.type === "Boolean");

const valueOptions = computed(() => props.property?.validationList ?? []);

function isValueSelected(value: any) {
	if (props.modelValue?.includes) {
		return props.modelValue.includes(value);
	}

	return value === props.modelValue;
}

watch(() => props.modelValue, initMultichoiceFieldset);

onMounted(initMultichoiceFieldset);

function initMultichoiceFieldset() {
	if (props.property.type.endsWith("[]")) {
		multichoiceModel.value = [...(props.modelValue ?? [])];
	}
}
</script>

<template>
	<div class="form-field">
		<label :for="fieldId">{{ property.title }}</label>
		<select
			v-if="isSingleChoice"
			:id="fieldId"
			class="form-select"
			v-model="modelValue"
			@change="emit('update:modelValue', modelValue)"
		>
			<option
				v-for="item in valueOptions"
				key="item"
				:class="{ selected: item === isValueSelected(item) }"
			>
				{{ item }}
			</option>
		</select>

		<div v-else-if="isMultichoice">
			<div v-for="itemValue in valueOptions" class="form-check">
				<input
					class="form-check-input"
					type="checkbox"
					v-model="multichoiceModel"
					:id="itemValue"
					:value="itemValue"
					@change="emit('update:modelValue', multichoiceModel)"
				/>
				<span class="form-check-label">{{ itemValue }}</span>
			</div>
		</div>

		<input
			v-else-if="isBoolean"
			:id="fieldId"
			class="form-check-input"
			type="checkbox"
			v-model="modelValue as boolean"
			@change="emit('update:modelValue', modelValue)"
		/>

		<input
			v-else
			:id="fieldId"
			:required="property.required"
			type="text"
			class="form-control"
			v-model="modelValue"
			@change="emit('update:modelValue', modelValue)"
		/>
	</div>
</template>

<style lang="scss" scoped>
.form-field {
	margin: 1em 0;
	display: flex;
	justify-content: space-between;
	align-items: baseline;
}

.form-field > label {
	flex-grow: 1 1 auto;

	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;

	margin-right: 1em;
}

.form-field > *:last-child {
	flex: 0 0 224px;
}

label {
	font-weight: 600;
	color: #444;
}
</style>
