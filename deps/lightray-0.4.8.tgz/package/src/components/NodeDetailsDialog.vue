<script lang="ts" setup>
import { computed, ref, watch, onMounted } from "vue";
import {
	Aspect,
	AspectProperty,
	Node,
	FileNode,
	FolderNode,
	SmartFolderNode,
	Properties,
} from "antbox";
import AspectPropertyField from "./AspectPropertyField.vue";
import { formatFileSize, formatToLocalDateTime } from "./node_helpers";

type Command = "show" | "hide" | "none";

const props = defineProps<{ node: Node; aspects: Aspect[]; command: Command }>();
const emit = defineEmits<{
	(e: "save", node: Node): void;
	(e: "close"): void;
}>();

const dialogRef = ref();
const modalRef = ref();

const state = ref({} as Node | FileNode | FolderNode | SmartFolderNode);
const size = computed(() => formatFileSize(props.node?.size ?? 0));
const createdTime = computed(() => formatToLocalDateTime(props.node?.createdTime));
const modifiedTime = computed(() => {
	return formatToLocalDateTime(props.node?.modifiedTime);
});

function handleChangeAspects() {
	const nodeProps: { [key: string]: unknown } = {};

	for (const aspectUuid of state.value.aspects ?? []) {
		const aspect = props.aspects?.find((el) => el.uuid === aspectUuid);

		for (const property of aspect?.properties ?? []) {
			const fieldName = aspectUuid.concat(":", property.name);
			nodeProps[fieldName] =
				state.value.properties?.[fieldName] ?? getDefaultValueFor(property);
		}
	}
	state.value.properties = nodeProps;
}

function getDefaultValueFor(property: AspectProperty) {
	if (property.default) return property.default;

	switch (property.type) {
		case "Boolean":
			return false;

		case "DateTime":
			return new Date().toISOString;

		case "Number":
			return 0;

		case "Number[]":
		case "String[]":
		case "UUID[]":
			return [];

		default:
			return "";
	}
}

function getAspect(uuid: string): Aspect | undefined {
	return props.aspects?.find((el: Aspect) => el.uuid === uuid);
}

function getAspectTitle(uuid: string): string | undefined {
	return getAspect(uuid)?.title;
}

function getAspectProperties(uuid: string) {
	return getAspect(uuid)?.properties ?? [];
}

const nodeAspects = computed(() => {
	const mapped = state.value.aspects?.map((el) => getAspect(el)?.title);
	return mapped;
});

onMounted(() => {
	const Modal = (window as any).bootstrap.Modal;
	modalRef.value = new Modal(dialogRef.value);
});

watch(
	() => ({ node: props.node, command: props.command }),
	({ node, command }) => {
		state.value = node ? ({ ...node } as Node) : ({} as Node);
		if (!state.value.properties) state.value.properties = {} as Properties;
		if (!state.value.aspects) state.value.aspects = [];

		if (command === "show") modalRef.value.show();
		else if (command === "hide") modalRef.value.hide();
	},
);
</script>

<template>
	<div ref="dialogRef" class="modal" tabindex="-1">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">{{ state?.title }}</h5>
					<button
						type="button"
						class="btn-close"
						data-bs-dismiss="modal"
						aria-label="Close"
					></button>
				</div>
				<div class="modal-body" v-if="state.uuid">
					<label class="fs-6">Geral</label>
					<hr />
					<div class="form-field">
						<label for="uuid">UUID</label>
						<input
							class="form-control"
							id="uuid"
							v-model="state.uuid"
							type="text"
							readonly
						/>
					</div>

					<div class="form-field">
						<label for="fid">ID Amigável</label>
						<input
							class="form-control"
							id="fid"
							v-model="state.fid"
							type="text"
						/>
					</div>

					<div class="form-field">
						<label for="title">Título</label>
						<input
							class="form-control"
							id="title"
							v-model="state.title"
							type="text"
						/>
					</div>
					<!--
					<div class="form-field">
						<label for="description?">description?</label>
						<input class="form-control" id="description" type="text" v-model="state.description" />
					</div>
					-->
					<div class="form-field">
						<div></div>
						<div class="form-check">
							<input
								class="form-check-input"
								type="checkbox"
								v-model="state.starred"
								id="starred"
							/>
							<label class="form-check-label" for="starred">Favorito</label>
						</div>
					</div>

					<div class="form-field">
						<label for="mimetype">Mimetype</label>
						<input
							class="form-control"
							id="mimetype"
							v-model="state.mimetype"
							type="text"
							readonly
						/>
					</div>

					<div class="form-field">
						<label for="aspects">Aspectos</label>
						<div>
							<div v-for="aspect in aspects" class="form-check">
								<input
									class="form-check-input"
									type="checkbox"
									v-model="state.aspects"
									:value="aspect.uuid"
									id="starred"
									@change="handleChangeAspects"
								/>
								<div class="form-check-label" for="starred">
									{{ aspect.title }}
								</div>
							</div>
						</div>
					</div>

					<div class="form-field">
						<label for="size">Tamanho</label>
						<input
							type="text"
							class="form-control"
							id="size"
							v-model="size"
							readonly
						/>
					</div>

					<div class="form-field">
						<label for="createdTime">Criado aos</label>
						<input
							class="form-control"
							id="createdTime"
							v-model="createdTime"
							type="text"
							readonly
						/>
					</div>

					<div class="form-field">
						<label for="modifiedTime">Modificado aos</label>
						<input
							class="form-control"
							id="modifiedTime"
							v-model="modifiedTime"
							type="text"
							readonly
						/>
					</div>
					<div class="form-field">
						<label for="owner">Proprietário</label>
						<input
							class="form-control"
							id="owner"
							v-model="state.owner"
							type="text"
							readonly
						/>
					</div>

					<div v-for="aspectUuid in state.aspects" :key="aspectUuid">
						<label class="fs-6">{{ getAspectTitle(aspectUuid) }}</label>
						<hr />
						<div
							v-for="property in getAspectProperties(aspectUuid)"
							:key="property.name"
						>
							<aspect-property-field
								v-if="state.properties"
								v-model="
									state.properties[aspectUuid + ':' + property.name]
								"
								:property="property"
							/>
						</div>
					</div>
				</div>

				<div class="modal-footer">
					<button type="button" class="btn" data-bs-dismiss="modal">
						Cancelar
					</button>
					<button
						type="button"
						class="btn btn-primary"
						@click="emit('save', state)"
					>
						Salvar
					</button>
				</div>
			</div>
		</div>
	</div>
</template>

<style lang="scss" scoped>
.modal,
.modal input,
select {
	font-size: 13px !important;
}

.form-field {
	margin: 0.5em 0;
	display: flex;
	justify-content: space-between;
	align-items: baseline;
}

.form-field > label {
	flex-grow: 1 1 auto;

	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;

	margin-right: 1em;
}

.form-field > *:last-child {
	flex: 0 0 296px;
}

label {
	font-weight: 500;
	color: #444;
}
</style>
