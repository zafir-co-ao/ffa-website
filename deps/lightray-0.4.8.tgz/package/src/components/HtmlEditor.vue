<script lang="ts" setup>
import { ref, watchEffect } from "vue";
import Editor from "@tinymce/tinymce-vue";

interface EditorProps {
	modelValue: string;
	apiKey?: string;
}

const EDITOR_INIT = {
	language: "pt_PT",
	plugins: "lists code",
	toolbar:
		"undo redo | bold italic underline strikethrough | formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist checklist | casechange removeformat | emoticons  | code",

	//contextmenu: "code",
};

withDefaults(defineProps<EditorProps>(), {
	apiKey: "fz5xyz1eiffj4av5nsyydhxthj4gd21nlzpv7tpy4t424v3z",
});
const emit = defineEmits<{ (e: "update:modelValue", value: string): void }>();

const loadEditor = ref(false);

watchEffect(() => {
	if (!loadEditor.value) {
		setTimeout(() => (loadEditor.value = true), 500);
	}
});
</script>

<template>
	<editor
		v-if="loadEditor"
		v-model="modelValue"
		:init="EDITOR_INIT"
		:api-key="apiKey"
		@change="emit('update:modelValue', modelValue)"
	/>
</template>

<style lang="scss">
#htmlEditor {
	min-height: 240px;
}
</style>
