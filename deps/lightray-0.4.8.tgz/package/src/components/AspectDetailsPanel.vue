<script lang="ts" setup>
import {Aspect} from "antbox";

const props = defineProps<{ aspect: Aspect }>();
</script>

<template>
	<div class="aspect-details">
		<div class="aspect-details__form" v-if="aspect">
			<span class="form-floating">
				<input
					id="uuid"
					:value="aspect.uuid"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="uuid">UUID</label>
			</span>

			<span class="form-floating">
				<input
					:value="aspect.title"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label>Título</label>
			</span>

			<span v-if="aspect.mimetypeConstraints" class="form-floating">
				<input
					:value="aspect.mimetypeConstraints.join(', ')"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label>Restringido a</label>
			</span>

			<label v-if="aspect.properties" class="fw-bold mb-2 mt-4">Propriedades</label>

			<div
				v-for="property in aspect.properties"
				:key="property.name"
				class="aspect-details-property d-flex mb-2"
			>
				<label class="flex-1 w-75">{{ property.title }} <span v-if="property.required">*</span></label>
				<span class="flex-1">{{ property.type }}</span>
			</div>
		</div>
	</div>
</template>

<style lang="scss" scoped>
.aspect-details__form {
	padding: 0.571em 1em;
	color: #333;
	box-sizing: border-box;
}

.form-floating label {
	width: max-content;
}
</style>
