<script lang="ts">
import { onMounted, ref, watch } from "vue";
import { Node } from "antbox";
</script>

<script lang="ts" setup>
type Command = "show" | "hide" | "none";

interface CodeEditorProps {
	node: Node;
	command: Command;
	content: string;
}

const props = defineProps<CodeEditorProps>();
const emit = defineEmits<{ (e: "save", content: string): void }>();

const modalRef = ref();
const dialogRef = ref();
const codeEditorRef = ref();
const editorRef = ref();

watch(
	() => props.content,
	() => {
		editorRef.value.setValue(props.content, -1);
		switch (props.node.mimetype) {
			case "text/javascript":
				editorRef.value.session.setMode("ace/mode/javascript");
				break;
			case "text/html":
				editorRef.value.session.setMode("ace/mode/html");
				break;
			case "application/json":
				editorRef.value.session.setMode("ace/mode/json");
				break;
			default:
				editorRef.value.session.setMode("ace/mode/text");
		}
	},
);

watch(
	() => props.command,
	(command) => {
		if (command === "show") modalRef.value.show();
		else if (command === "hide") modalRef.value.hide();
	},
);

onMounted(() => {
	const Modal = (window as any).bootstrap.Modal;
	modalRef.value = new Modal(dialogRef.value);

	const ace = (window as any).ace;
	ace.config.set("basePath", "https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.13");

	editorRef.value = ace.edit(codeEditorRef.value);
	editorRef.value.setTheme("ace/theme/eclipse");
});

function save() {
	emit("save", editorRef.value.getValue());
}
</script>

<template>
	<div ref="dialogRef" class="modal" tabindex="-1">
		<div class="modal-dialog modal-xl">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">{{ node?.title }}</h5>
					<button
						type="button"
						class="btn-close"
						data-bs-dismiss="modal"
						aria-label="Close"
					></button>
				</div>
				<div class="modal-body">
					<div ref="codeEditorRef" style="min-height: 320px"></div>
				</div>

				<div class="modal-footer">
					<button type="button" class="btn" data-bs-dismiss="modal">
						Cancelar
					</button>
					<button type="button" class="btn btn-primary" @click="save">
						Gravar
					</button>
				</div>
			</div>
		</div>
	</div>
</template>
