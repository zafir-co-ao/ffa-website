const SEVERITY_COLORS = {
	info: "#007AFF",
	success: "#3FBF41",
	warn: "#C48541",
	error: "#F93943 ",
};

export type ToastSeverity = "info" | "success" | "warn" | "error";

export interface ToastArguments {
	severity?: ToastSeverity;
	summary?: string;
	detail?: string;
	life?: number;
	closable?: boolean;
	group?: string;
}

export interface Toast {
	add(args: ToastArguments): void;
	exception(err: Error, detail?: string, summary?: string);
	success(detail: string, summary?: string);
	info(detail: string, summary?: string);
	warn(detail: string, summary?: string);
}

export function useToast(placeholder: HTMLElement | string): Toast {
	const root =
		typeof placeholder === "string"
			? document.querySelector(placeholder)
			: placeholder;

	const toastContainer = buildToastContainer();

	root?.appendChild(toastContainer);

	return {
		add: (args: ToastArguments) => addToast(toastContainer, args),

		exception: (err: Error, message?: string, summary = "Ocorreu um erro") => {
			const severity = "error";
			const detail = message ?? err.message;

			addToast(toastContainer, { detail, summary, severity, life: 10000 });
			console.error(err);
		},

		success: (detail: string, summary = "Operação concluída com sucesso") => {
			const severity = "success";
			addToast(toastContainer, { detail, summary, severity, life: 10000 });
		},

		info: (detail: string, summary?: string) => {
			const severity = "info";
			addToast(toastContainer, { detail, summary, severity, life: 10000 });
		},

		warn: (detail: string, summary?: string) => {
			const severity = "warn";
			addToast(toastContainer, { detail, summary, severity, life: 10000 });
		},
	};
}

function addToast(container: HTMLDivElement, args: ToastArguments) {
	const toast = buildToast(args);

	container.appendChild(toast);

	bootstrap().Toast.getOrCreateInstance(toast).show();
}

function buildElementFromString<T>(innerHTML: string): T {
	const div = document.createElement("div");

	div.innerHTML = innerHTML.trim();

	return div.firstChild as unknown as T;
}

function buildToast({ summary, detail, severity }: ToastArguments): HTMLDivElement {
	return buildElementFromString<HTMLDivElement>(`
		<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
			<div class="toast-header">
				<svg class="bd-placeholder-img rounded me-2" width="20" height="20" 
					xmlns="http://www.w3.org/2000/svg" aria-hidden="true" 
					preserveAspectRatio="xMidYMid slice" focusable="false">
					<rect width="100%" height="100%" fill="${SEVERITY_COLORS[severity]}"></rect>
				</svg>
				<strong class="me-auto">${summary ?? ""}</strong>
				<small></small>
				<button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
			</div>
			<div class="toast-body">${detail ?? ""}</div>
		</div>`);
}

function buildToastContainer() {
	return buildElementFromString<HTMLDivElement>(`
		<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:100">
		</div>`);
}

function bootstrap(): any {
	return (window as any).bootstrap;
}
