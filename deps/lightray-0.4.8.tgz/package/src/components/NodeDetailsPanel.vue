<script lang="ts" setup>
import { computed, ref, watch } from "vue";
import { formatToLocalDateTime } from "./node_helpers";
import { Node } from "antbox";

const props = defineProps<{ node: Node }>();
const emit = defineEmits<{ (e: "save", node: Partial<Node>): void }>();

const fid = ref(props.node.fid);
const title = ref(props.node.title);
const description = ref(props.node.description);
const starred = ref(props.node.starred);

//const size = computed(() => formatFileSize(props.node?.size ?? 0));
const createdTime = computed(() => formatToLocalDateTime(props.node?.createdTime));
const modifiedTime = computed(() => {
	return formatToLocalDateTime(props.node?.modifiedTime);
});

watch(() => props.node, (node: Node) => {
	fid.value = node?.fid;
	title.value = node?.title;
	description.value = node?.description;
	starred.value = node?.starred;
});

function emitSave() {
	emit("save", {
		uuid: props.node?.uuid,
		fid: fid.value,
		title: title.value,
		description: description.value,
		starred: starred.value,
	});
}
</script>

<template>
	<div class="quick-edit">
		<div class="quick-edit__form">
			<span class="form-floating">
				<input
					id="uuid"
					:value="node.uuid"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="uuid">UUID</label>
			</span>

			<span class="form-floating">
				<input
					id="fid"
					v-model="fid"
					class="form-control form-control-sm mb-2"
					type="text"
				/>
				<label for="fid">ID Amigável</label>
			</span>

			<span class="form-floating">
				<input
					id="title"
					v-model="title"
					class="form-control form-control-sm mb-2"
					type="text"
				/>
				<label for="title">Título</label>
			</span>

			<span class="form-floating">
				<input
					id="uuid"
					:value="node.aspects?.join(', ')"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="aspects">Aspectos</label>
			</span>
			<!--
			<span class="form-floating">
				<input class="form-control form-control-sm mb-2"    id="description" type="text" v-model="description" />
				<label for="description?">description?</label>
			</span>
            -->
			<div class="form-check mb-4 mt-4">
				<input class="form-check-input" type="checkbox" v-model="starred" id="starred" />
				<label class="form-check-label" for="starred">Favorito</label>
			</div>

			<span class="form-floating">
				<input
					id="mimetype"
					v-model="node.mimetype"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="mimetype">Mimetype</label>
			</span>
			<!--
			<span class="form-floating">
				<input
					id="size"
					v-model="size"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="size">Tamanho</label>
			</span>
			-->
			<span class="form-floating">
				<input
					id="createdTime"
					v-model="createdTime"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="createdTime">Criado aos</label>
			</span>

			<span class="form-floating">
				<input
					id="modifiedTime"
					v-model="modifiedTime"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="modifiedTime">Modificado aos</label>
			</span>

			<span class="form-floating">
				<input
					id="owner"
					v-model="node.owner"
					class="form-control form-control-sm mb-2"
					type="text"
					readonly
				/>
				<label for="owner">Proprietário</label>
			</span>

			<div class="quick-edit__actions">
				<button type="button" class="btn btn-primary" @click="emitSave">
					Salvar &nbsp;
					<span class="bi bi-save"></span>
				</button>
			</div>
		</div>
	</div>
</template>

<style lang="scss" scoped>
.quick-edit__form {
	padding: 0.571em 1em;
	color: #333;
	box-sizing: border-box;
}

.quick-edit__actions {
	padding: 0.5em 0;
	text-align: right;
}

.form-floating label {
	width: max-content;
}
</style>
