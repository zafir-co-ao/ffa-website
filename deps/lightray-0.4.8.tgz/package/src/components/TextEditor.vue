<script lang="ts">
const HTML_MIMETYPE = "text/html";

async function loadNodeContent(nodeService: NodeServiceClient, uuid: string) {
	const node = await nodeService.get(uuid);
	const blob = await nodeService.export(uuid);

	return {
		title: node.title,
		mimetype: node.mimetype,
		content: await blob.text(),
	};
}

async function updateNodeFile(
	nodeService: NodeServiceClient,
	uuid: string,
	content: string,
	mimetype: string,
) {
	const file = new File([new Blob([content])], "", { type: mimetype });
	return nodeService.updateFile(uuid as string, file);
}
</script>

<script lang="ts" setup>
import { computed, onMounted, Ref, ref } from "vue";
import { useRouter } from "vue-router";

import nodeServiceClient, { NodeServiceClient } from "../api_clients/node_service_client";
import { useToast, Toast } from "./toasts";
import LoadingSpinner from "./LoadingSpinner.vue";
import HtmlEditor from "./HtmlEditor.vue";
import CodeEditor from "./CodeEditor.vue";

const props = defineProps<{ uuid: String }>();

const textEditorRef = ref();

const nodeService = nodeServiceClient;
let toast: Toast;
const router = useRouter();

const title: Ref<string | undefined> = ref();
const mimetype = ref("");
const content = ref("");

const isHtml = computed(() => mimetype.value === HTML_MIMETYPE);
const isLoading = computed(() => !title.value);

async function saveContent() {
	try {
		await updateNodeFile(
			nodeService,
			props.uuid as string,
			content.value,
			mimetype.value,
		);
		toast.success("Conteúdo gravado com sucesso");
		close();
	} catch (err) {
		toast.exception(err as Error, "Não foi possível gravar as alterações");
	}
}

function close() {
	router.back();
}

onMounted(async () => {
	try {
		toast = useToast(textEditorRef.value as HTMLElement);
		const options = await loadNodeContent(nodeService, props.uuid as string);

		title.value = options.title;
		mimetype.value = options.mimetype;
		content.value = options.content;
	} catch (err) {
		toast.exception(err as Error, "Não foi possível carregar o conteúdo");
		close();
	}
});
</script>

<template>
	<div class="text-editor" ref="textEditorRef">
		<div class="text-editor__content">
			<h2>{{ title }}</h2>

			<LoadingSpinner v-if="isLoading" />

			<v-container v-else>
				<HtmlEditor v-if="isHtml" v-model="content" type="classic"></HtmlEditor>
				<CodeEditor v-else v-model="content" :mimetype="mimetype"></CodeEditor>
			</v-container>
		</div>
		<div class="text-editor__footer">
			<button type="button" class="btn" @click="close">Cancelar</button>
			<button type="button" class="btn btn-primary" @click="saveContent">
				Salvar
			</button>
		</div>
	</div>
</template>

<style lang="scss" scoped>
.text-editor {
	padding: 1em;
	display: flex;
	flex-flow: column;
	height: 100vh;
	justify-content: space-between;
}

.text-editor__content {
	flex: 1 1 auto;
}

.text-editor__content h2 {
	margin-bottom: 0.5em;
}

.text-editor__footer {
	padding-top: 1em;
	text-align: right;
}

.text-editor__footer > * {
	flex: 0 0 auto;
	margin-left: 0.5em;
}
</style>
