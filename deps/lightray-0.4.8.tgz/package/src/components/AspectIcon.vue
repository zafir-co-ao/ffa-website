<script lang="ts" setup>
const IMG_HREF = "/images/lightray/mimetypes/text-css.svg" 
defineProps<{ uuid: string; title: string; selected: boolean }>();
const emit =
	defineEmits<{ (e: "select", uuid: string): void; (e: "download", uuid: string): void }>();
</script>

<template>
	<div class="aspect-wrapper">
		<div
			class="aspect-wrapper__inner"
			:class="{ 'aspect-wrapper__inner--selected': selected }"
			@click="emit('select', uuid)"
			@dblclick="emit('download', uuid)"
		>
			<img
				class="aspect-icon"
				draggable="false"
				:src="IMG_HREF"
			/>
			<div class="aspect-title">{{ title }}</div>
		</div>
	</div>
</template>

<style lang="scss" scoped>
$icon-width: 64px;
$title-width: 84px;
$icon-margin: 8px;

$selected-color: #e3f2fd;

.aspect-wrapper,
.aspect-wrapper__inner {
	padding: $icon-margin;
}

.aspect-wrapper__inner {
	display: flex;
	flex-direction: column;
	align-items: center;
	border-radius: 4px;

	position: relative;
}

.aspect-wrapper__inner--selected {
	background-color: $selected-color;
	outline-offset: -4px;
	outline: 4px solid transparent;
}

.aspect-wrapper__inner:hover {
	cursor: pointer;
}

.aspect-icon {
	width: $icon-width;
	height: $icon-width;

	background-size: contain;
}

.aspect-title {
	box-sizing: border-box;
	
	line-height: 1.5em;

	margin-top: 4px;

	width: $title-width;
	max-height: 3em;
	overflow: hidden;
	text-overflow: ellipsis;
	text-align: center;
}
</style>
