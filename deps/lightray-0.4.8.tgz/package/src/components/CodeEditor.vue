<template>
	<div class="lr-code-editor">
		<div :id="editorId"></div>
	</div>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from "vue";
// import { CodeEditor, mountAce } from "@/ports/code-editor";

const editorId = "CodeEditorId";

const props = defineProps<{ modelValue: String; mimetype: String }>();
const emit = defineEmits(["update:modelValue"]);

const editor = ref();

onMounted(() => {
	//editor.value = getAceEditor(props.mimetype ?? "text/plain");
	editor.value?.set(props.modelValue ?? "");
	editor.value?.onChange(() => emit("update:modelValue", editor.value?.get()));
});

watch(props, () => {
	editor.value?.set(props.modelValue);
});

/*
function getAceEditor(mimetype: string): CodeEditor {
	return mountAce(EDITOR_ID, mimetype);
}
*/
</script>

<style lang="scss" scoped>
.ace_editor {
	min-height: calc(100vh - 204px);
}

.ace_editor {
	border: 1px solid var(--bluegray-200);
	border-radius: 4px;
	font-size: 13px;
}

.ace_gutter,
.ace_scroller {
	box-sizing: border-box;
	padding-top: 1em;
	padding-bottom: 2em;
}
</style>
