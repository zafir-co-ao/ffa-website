<script lang="ts" setup>
import { onMounted, ref } from "vue";
import { WebContentClient, NodeServiceClient } from "./types";
import WebContentEditorDialog from "./WebContentEditorDialog.vue";

interface WebContentProps {
	uuid: string;
	lang: string;
	editionAllowed?: boolean;
	webContentServiceClient: WebContentClient;
	nodeServiceClient?: NodeServiceClient;
}

const { uuid, lang, webContentServiceClient, nodeServiceClient } = withDefaults(
	defineProps<WebContentProps>(),
	{ editionAllowed: false },
);

const content = ref<string>("");
const node = ref();
const webContent = ref();
const editionDialogCommand = ref<"show" | "hide" | "none">("none");

async function edit() {
	webContent.value = await nodeServiceClient
		.export(uuid)
		.then((blob) => blob.text())
		.then((text) => JSON.parse(text));

	editionDialogCommand.value = "show";
}

async function save(value) {
	const file = new File([value], node.value.title, {
		type: "application/json",
	});
	await nodeServiceClient.updateFile(uuid, file);

	editionDialogCommand.value = "show";
	loadContent();
}

async function loadContent() {
	content.value = await webContentServiceClient?.get(uuid, lang);
}

onMounted(loadContent);
</script>

<template>
	<div class="web-content-container">
		<div v-html="content" />
		<div v-if="editionAllowed" class="edition-button-container">
			<i class="bi bi-pencil-square" @click="edit"></i>
		</div>
		<web-content-editor-dialog
			:node="node"
			:content="webContent"
			:command="editionDialogCommand"
			@save="save"
		/>
	</div>
</template>

<style scoped>
.web-content-container {
	position: relative;
}

.edition-button-container {
	position: absolute;
	right: 0px;
	top: 0px;
	cursor: pointer;
	color: blue;
}
</style>
