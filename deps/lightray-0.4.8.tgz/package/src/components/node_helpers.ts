export function formatFileSize(size: number): string {
	const { value, unit } = extractFileSizeValueAndUnit(size);

	return value.toLocaleString("pt").concat(" ", unit);
}

export function formatToLocalDateTime(value: string | Date): string {
	const toConvert = typeof value === "string" ? new Date(Date.parse(value)) : value;

	//const format = new Intl.DateTimeFormat("pt", {timeZone})
	return toConvert?.toLocaleString("pt");
}

function extractFileSizeValueAndUnit(value: number): { value: number; unit: string } {
	const [kb, mb, gb] = FILESIZES;

	if (value < kb) return { value, unit: "bytes" };

	if (value < mb) return { value: toFixedIfNeeded(value / kb), unit: "KB" };

	if (value < gb) return { value: toFixedIfNeeded(value / mb), unit: "MB" };

	return { value: toFixedIfNeeded(value / gb), unit: "GB" };
}

function toFixedIfNeeded(value: number) {
	return +value.toFixed(2);
}

const FILESIZES = [1024, 1024 * 1024, 1024 * 1024 * 1024];
