<template>
	<div class="screen-size-indicator">
		<b class="d-inline">
			<span class="d-inline-block">col/xs</span>&nbsp;
			<span class="d-none d-sm-inline-block">sm</span>&nbsp;
			<span class="d-none d-md-inline-block">md</span>&nbsp;
			<span class="d-none d-lg-inline-block">lg</span>&nbsp;
			<span class="d-none d-xl-inline-block">xl</span>&nbsp;
		</b>
	</div>
</template>

<style lang="scss" scoped>
.screen-size-indicator {
	z-index: 19191919;
	position: fixed;
	left: 0px;
	top: 0px;
	background-color: black;
	color: white;
	font-size: 12px;
	line-height: 12px;
	padding: 4px;
}
</style>
