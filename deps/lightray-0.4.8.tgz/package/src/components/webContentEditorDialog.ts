import { WebContent } from "antbox";

export type WebContentEditorCommand = "show" | "hide" | "none";

export interface WebContentEditorProps {
	title?: string;
	command: WebContentEditorCommand;
	content: WebContent;
}

export interface WebContentEditorEvents {
	(e: "save", content: WebContent): void;
	(e: "update:command", command: WebContentEditorCommand): void;
}
