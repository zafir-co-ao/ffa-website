<script lang="ts" setup>
import { computed, onMounted, Ref, ref, reactive } from "vue";
import { RouteLocationRaw, useRouter } from "vue-router";

import NodesRendererSection from "./NodesRendererSection.vue";
import LoadingSpinner from "./LoadingSpinner.vue";
import NodeDetailsPanel from "./NodeDetailsPanel.vue";
import NodeDetailsDialog from "./NodeDetailsDialog.vue";
import WebContentEditorDialog from "./WebContentEditorDialog.vue";
import CodeEditorDialog from "./CodeEditorDialog.vue";
import { AspectServiceClient, NodeServiceClient } from "./types";

import {
	Node,
	Aspect,
	FileNode,
	FolderNode,
	SmartFolderNode,
	WebContent,
	ROOT_FOLDER_UUID,
	FOLDER_MIMETYPE,
	SMART_FOLDER_MIMETYPE,
} from "antbox";

import { Toast, useToast } from "./toasts";

const TEXT_ASPECTS_RE = /^(application\/json|text\/\w+)/;

interface DiscoveryState {
	availableAspects: Aspect[];
	contextItems: ContextMenuItem[];
	makeableFileAspects: Aspect[];
	makeableFolderAspects: Aspect[];
	fileNodes: FileNode[];
	folderNodes: FolderNode[];
	smartFolderNodes: SmartFolderNode[];

	selectedUuids: string[];
	loading: boolean;

	nodeEditModel: Node;
	nodeEditAspects: Aspect[];
	nodeEditCommand: "show" | "hide" | "none";

	webContentCommand: "show" | "hide" | "none";
	webContent: WebContent;

	codeContent: string;
	codeCommand: "show" | "hide" | "none";

	breadcrumbItems: { uuid: string; label: string }[];
}

interface DropdownButton {
	show(): void;
	toggle(): void;
	hide(): void;
}

interface ContextMenuItem {
	bootstrapIcon?: string;
	title?: string;
	cb?: () => void;
	separator?: boolean;
}

const { aspectServiceClient, nodeServiceClient } = defineProps<{
	aspectServiceClient: AspectServiceClient;
	nodeServiceClient: NodeServiceClient;
}>();

const state: DiscoveryState = reactive(inititializeState());

let toast: Toast;
const router = useRouter();

const fileUploadRef = ref<HTMLInputElement>();
const menuRef = ref<DropdownButton>();
const contextMenuRef = ref<DropdownButton>();

const selectedNode = computed(() => {
	if (state.selectedUuids.length !== 1) return;

	return (state.folderNodes as Node[])
		.concat(state.smartFolderNodes)
		.concat(state.fileNodes)
		.find((el) => el.uuid === state.selectedUuids[0]) as Node;
});

function handleInfo(detail: string, summary?: string) {
	toast.info(detail, summary);
}

function handleSuccess(detail: string, summary?: string) {
	toast.success(detail, summary);
}

function handleException(err: Error, detail: string, summary?: string) {
	toast.exception(err, detail, summary);
}

function navigate(to: RouteLocationRaw) {
	router.push(to);
}

function handleMultipleSelect(uuid: string): void {
	const index = state.selectedUuids.indexOf(uuid);

	if (index === -1) {
		state.selectedUuids.push(uuid);
	} else {
		state.selectedUuids.splice(index, 1);
	}
}

function handleFileUpload() {
	if (fileUploadRef.value?.files) {
		const inputFileElement = fileUploadRef.value;

		uploadFile(inputFileElement.files).then(() => (inputFileElement.value = ""));
	}
}

onMounted(async () => {
	toast = useToast(".discovery");
	await aspectServiceClient.list().then((aspects) => {
		state.availableAspects = aspects;
		state.makeableFileAspects = aspects.filter(isMakeableFileAspect);
		state.makeableFolderAspects = aspects.filter(isMakeableFolderAspect);
	});

	inititializeMenu(menuRef, "menuButton");
	inititializeMenu(contextMenuRef, "contextMenuButton");

	restoreState();
	handleOpenFolder(pwd());
});

const isSelected = (uuid: string) => state.selectedUuids.includes(uuid);

const handleSelect = (uuid: string) => (state.selectedUuids = [uuid]);

const handleSaveNodeProperties = (data: Partial<Node>) => {
	updateNode(data).then(() => {
		state.nodeEditCommand = "hide";
	});
};

const handleSaveWebContent = (data: WebContent) => {
	updateTextContent(JSON.stringify(data)).then(() => {
		state.webContentCommand = "hide";
	});
};

const handleSaveCodeContent = (data: string) => {
	updateTextContent(data).then(() => {
		state.codeCommand = "hide";
	});
};

const handleRefresh = () => handleOpenFolder(pwd());

const handleBreadcrumbClick = (uuid?: string) => handleOpenFolder(uuid);

async function createFolder() {
	const parentUuid = pwd();

	return nodeServiceClient
		.createFolder("Nova Pasta", parentUuid)
		.then(() => handleOpenFolder(parentUuid))
		.catch((err) => handleException(err, "Não foi possível criar a pasta"));
}

async function createTypedFolder(aspect: Aspect) {
	const parent = pwd();

	return nodeServiceClient
		.createFolder(`Novo ${aspect.title}`, parent)
		.then((uuid) => nodeServiceClient.update(uuid, { aspects: [aspect.uuid] }))
		.then(() => handleOpenFolder(parent))
		.catch((err) => handleException(err, "Não foi possível criar o ficheiro"));
}

async function createTextFile(aspect: Aspect) {
	const type = aspect.mimetypeConstraints.find((a) => TEXT_ASPECTS_RE.test(a));

	const file = new File(
		['{ "pt" : "// Criado com lightray"}'],
		`Novo ${aspect.title}`,
		{ type },
	);
	const parent = pwd();

	return nodeServiceClient
		.createFile(file, parent)
		.then((uuid) => {
			nodeServiceClient.update(uuid, { aspects: [aspect.uuid] });
		})
		.then(() => handleOpenFolder(parent))
		.catch((err) => handleException(err, "Não foi possível criar o ficheiro"));
}

function inititializeState(): DiscoveryState {
	return {
		contextItems: [],
		makeableFileAspects: [],
		makeableFolderAspects: [],
		fileNodes: [],
		folderNodes: [],
		smartFolderNodes: [],

		selectedUuids: [],
		loading: false,

		nodeEditModel: {} as unknown as Node,
		nodeEditAspects: [],
		nodeEditCommand: "none",

		breadcrumbItems: [],
		availableAspects: [],

		codeCommand: "none",
		codeContent: "",

		webContent: {} as WebContent,
		webContentCommand: "none",
	};
}

function bootstrap(): any {
	return (window as any).bootstrap;
}

function inititializeMenu(menuRef: Ref, elementId: string) {
	const el = document.getElementById(elementId);
	const Dropdown = bootstrap().Dropdown;
	menuRef.value = new Dropdown(el);
}

function pwd(): string {
	return (
		state.breadcrumbItems[state.breadcrumbItems.length - 1]?.uuid ?? ROOT_FOLDER_UUID
	);
}

async function uploadFile(files: FileList | null) {
	if (files?.length) {
		const uuid = pwd();

		try {
			handleInfo("Os ficheiros estão a ser carregados, aguarde por favor...");
			for (let i = 0; i < files.length; i++)
				await nodeServiceClient.createFile(files[i] as File, uuid);

			handleSuccess("Ficheiros(s) carregados com sucesso");
		} catch (err) {
			handleException(
				err as Error,
				"Um ou mais carregamentos não foram bem sucedidos",
			);
		} finally {
			handleOpenFolder(uuid);
		}
	}
}

async function handleOpenFolder(uuid = ROOT_FOLDER_UUID) {
	const label =
		uuid === ROOT_FOLDER_UUID
			? ""
			: (state.folderNodes.find((el) => el.uuid === uuid) as FolderNode)?.title ??
			  "";

	try {
		state.loading = true;

		const nodes = await nodeServiceClient.list(uuid);

		const { files, folders, smartFolders } = splitFilesAndFolders(nodes);

		updateNodesState(files, folders, smartFolders);
		udpdateBreadcrumbs(uuid, label);
		saveState();
	} catch (err) {
		handleException(err as Error, "Ocorreu um erro inesperado ao abrir a pasta");
		console.error(err);
	} finally {
		state.loading = false;
	}
}

async function handleOpenSmartFolder(uuid?: string) {
	throw new Error("Not implemented");
}

async function handleDownload(uuid: string) {
	const node = state.fileNodes.find((el) => el.uuid === uuid) as FileNode;
	try {
		const file = await nodeServiceClient.export(uuid);

		const anchor = document.createElement("a");
		anchor.href = URL.createObjectURL(file);

		anchor.download = node.title ?? "download";
		anchor.type = node.mimetype;
		anchor.target = "_blank";
		anchor.click();
	} catch (err) {
		handleException(err as Error, "A descarga do ficheiro não foi bem sucedida");
	}
}

async function updateNode(values: Partial<Node>) {
	const { uuid, ...data } = values;
	try {
		await nodeServiceClient.update(uuid as string, data);
		handleSuccess("Dados salvos com sucesso");
		handleOpenFolder(pwd());
	} catch (err) {
		handleException(err as Error, "Um ou mais carregamentos não foram bem sucedidos");
	}
}

async function updateTextContent(value: string) {
	const file = new File([value], state.nodeEditModel.title, {
		type: state.nodeEditModel.mimetype,
	});
	try {
		await nodeServiceClient.updateFile(state.nodeEditModel.uuid, file);
		handleSuccess("Dados salvos com sucesso");
		handleOpenFolder(pwd());
	} catch (err) {
		handleException(err as Error, "Um ou mais carregamentos não foram bem sucedidos");
	}
}

async function deleteNode(uuid: string) {
	try {
		await nodeServiceClient.delete(uuid);
		handleOpenFolder(pwd());
		handleSuccess("Ficheiro apagado");
	} catch (err) {
		handleException(err as Error, "Não foi possível apagar o ficheiro");
	}
}

function makeBaseContext(node: Node): ContextMenuItem[] {
	return [
		makePropertiesContextItem(state, node),
		{ separator: true },
		{
			title: "Apagar",
			bootstrapIcon: "trash",
			cb: () => deleteNode(node.uuid),
		},
	];
}

function makePropertiesContextItem(state: DiscoveryState, node: Node): ContextMenuItem {
	return {
		title: "Propriedades",
		bootstrapIcon: "cog",
		cb: () => {
			const validAspects = (a: Aspect) => {
				return (
					!a.mimetypeConstraints?.length ||
					a.mimetypeConstraints?.includes(node.mimetype)
				);
			};

			state.nodeEditModel = JSON.parse(JSON.stringify(node));
			state.nodeEditAspects = state.availableAspects.filter(validAspects);
			state.nodeEditCommand = "show";
		},
	};
}

function showContextMenu(event: MouseEvent) {
	const el = document.getElementById("contextMenuWrapper");

	if (!el) return;

	el.style.top = `${event.y}px`;
	el.style.left = `${event.x}px`;

	contextMenuRef.value?.show();
}

function handleFileContext({ uuid, event }: { uuid: string; event: MouseEvent }) {
	const node = state.fileNodes.find((el) => el.uuid === uuid) as Node;
	state.nodeEditModel = JSON.parse(JSON.stringify(node));

	const downloadMenuItem = {
		title: "Transferir",
		bootstrapIcon: "download",
		cb: () => handleDownload(uuid),
	};

	state.contextItems = [downloadMenuItem, ...makeBaseContext(node)];

	if (isTextNode(node)) {
		if (isWebContentNode(node)) {
			state.contextItems = [
				makeEditWebContentMenuItem(uuid),
				...state.contextItems,
			];
		}

		state.contextItems = [makeEditCodeMenuItem(uuid), ...state.contextItems];
	}
	showContextMenu(event);
}

function isWebContentNode(node: Node) {
	return node.aspects?.includes("web-content");
}

function isTextNode(node: Node) {
	return TEXT_ASPECTS_RE.test(node.mimetype);
}

function makeEditCodeMenuItem(uuid: string): ContextMenuItem {
	return {
		title: "Editar",
		bootstrapIcon: "pencil",
		cb: () => {
			nodeServiceClient
				.export(uuid)
				.then((blob) => blob.text())
				.then((code) => {
					state.codeContent = code;
					state.codeCommand = "show";
				});
		},
	};
}

function makeEditWebContentMenuItem(uuid: string): ContextMenuItem {
	return {
		title: "Editar Conteúdo Web",
		bootstrapIcon: "pencil",
		cb: () => {
			nodeServiceClient
				.export(uuid)
				.then((blob) => blob.text())
				.then((text) => JSON.parse(text))
				.then((node) => {
					state.webContent = node;
					state.webContentCommand = "show";
				});
		},
	};
}

function handleFolderContext({ uuid, event }: { uuid: string; event: MouseEvent }) {
	const node = getNodeFromArray(state.folderNodes, uuid);
	state.contextItems = makeBaseContext(node);

	showContextMenu(event);
}

function handleSmartFolderContext({ uuid, event }: { uuid: string; event: MouseEvent }) {
	const node = getNodeFromArray(state.smartFolderNodes, uuid);
	state.contextItems = makeBaseContext(node);

	showContextMenu(event);
}

function getNodeFromArray(a: Node[], uuid: string): Node {
	return a.find((el) => el.uuid === uuid) as Node;
}

function isMakeableFileAspect(aspect: Aspect): boolean {
	return aspect.mimetypeConstraints?.some((a) => TEXT_ASPECTS_RE.test(a)) ?? false;
}

function isMakeableFolderAspect(aspect: Aspect): boolean {
	return aspect.mimetypeConstraints?.some((a) => a === "application/folder");
}

function updateNodesState(
	files: FileNode[],
	folders: FolderNode[],
	smartFolders: SmartFolderNode[],
) {
	state.fileNodes = files;
	state.folderNodes = folders;
	state.smartFolderNodes = smartFolders;

	state.selectedUuids = [];
}

function udpdateBreadcrumbs(uuid: string, label: string) {
	if (uuid === ROOT_FOLDER_UUID) {
		state.breadcrumbItems = [];
		return;
	}

	const index = state.breadcrumbItems.findIndex((i) => i.uuid === uuid);

	if (index !== -1) {
		state.breadcrumbItems.splice(index + 1);
		return;
	}

	state.breadcrumbItems.push({ uuid, label });
}

function saveState() {
	const stateToSave = { breadcrumbs: state.breadcrumbItems };
	sessionStorage.setItem("lightray.discovery.state", JSON.stringify(stateToSave));
}

function restoreState() {
	const stateToRestore = sessionStorage.getItem("lightray.discovery.state");

	if (stateToRestore) {
		state.breadcrumbItems = JSON.parse(stateToRestore).breadcrumbs;
	}
}

function splitFilesAndFolders(nodes: Node[]): {
	files: FileNode[];
	folders: FolderNode[];
	smartFolders: SmartFolderNode[];
} {
	const isFolder = (node: Node) => node.mimetype === FOLDER_MIMETYPE;
	const isSmartFolder = (node: Node) => node.mimetype === SMART_FOLDER_MIMETYPE;
	const isFile = (node: Node) => !isFolder(node) && !isSmartFolder(node);

	const sortFn = (a: Node, b: Node) => (a.title < b.title ? -1 : 1);

	return {
		files: nodes.filter(isFile).sort(sortFn) as unknown as FileNode[],
		folders: nodes.filter(isFolder).sort(sortFn) as unknown as FolderNode[],
		smartFolders: nodes
			.filter(isSmartFolder)
			.sort(sortFn) as unknown as SmartFolderNode[],
	};
}
</script>

<template>
	<div>
		<div class="discovery">
			<!--
		<div class="discovery__header">Header</div>
		-->
			<div class="discovery__main">
				<div class="discovery__content">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item">
								<a href="#" @click="handleBreadcrumbClick()">Home</a>
							</li>
							<li
								v-for="item in state.breadcrumbItems"
								:key="item.uuid"
								class="breadcrumb-item"
								@click="handleBreadcrumbClick(item.uuid)"
							>
								<a href="#">{{ item.label }}</a>
							</li>
						</ol>
					</nav>

					<div class="discovery__toolbar">
						<div class="dropdown">
							<button
								class="btn btn-lg"
								id="menuButton"
								type="button"
								data-bs-toggle="dropdown"
								aria-expanded="false"
								@click="menuRef?.show()"
							>
								<span class="bi bi-plus-circle"></span>
							</button>

							<ul class="dropdown-menu" aria-labelledby="menuButton">
								<li v-for="aspect in state.makeableFileAspects">
									<a
										class="dropdown-item"
										href="#"
										@click="createTextFile(aspect)"
										>Novo {{ aspect.title }}</a
									>
								</li>
								<li v-for="aspect in state.makeableFolderAspects">
									<a
										class="dropdown-item"
										href="#"
										@click="createTypedFolder(aspect)"
										>Novo {{ aspect.title }}</a
									>
								</li>
								<li><hr class="dropdown-divider" /></li>
								<li>
									<a
										class="dropdown-item"
										href="#"
										@click="fileUploadRef?.click()"
										>Carregar ficheiro(s)</a
									>
								</li>
								<li>
									<a
										class="dropdown-item"
										href="#"
										@click="createFolder()"
										>Nova Pasta</a
									>
								</li>
							</ul>
						</div>

						<button class="btn btn-lg" type="button" @click="handleRefresh">
							<span class="bi bi-arrow-clockwise"></span>
						</button>
					</div>

					<div v-if="!state.loading" class="discovery__nodes">
						<NodesRendererSection
							title="Pastas"
							:nodes="state.folderNodes"
							:is-selected-fn="isSelected"
							@multipleSelect="handleMultipleSelect"
							@select="handleSelect"
							@open="handleOpenFolder"
							@context="handleFolderContext"
						/>

						<NodesRendererSection
							title="Pastas Inteligentes"
							:nodes="state.smartFolderNodes"
							:is-selected-fn="isSelected"
							@multipleSelect="handleMultipleSelect"
							@select="handleSelect"
							@open="handleOpenSmartFolder"
							@context="handleSmartFolderContext"
						/>

						<NodesRendererSection
							title="Ficheiros"
							:nodes="state.fileNodes"
							:is-selected-fn="isSelected"
							@multipleSelect="handleMultipleSelect"
							@select="handleSelect"
							@open="handleDownload"
							@context="handleFileContext"
						/>
					</div>
					<div v-else class="discovery__nodes">
						<LoadingSpinner />
					</div>
				</div>
				<div class="discovery__details d-none d-lg-block">
					<NodeDetailsPanel
						v-if="selectedNode"
						:node="selectedNode"
						@save="updateNode"
					></NodeDetailsPanel>
				</div>
			</div>
		</div>

		<NodeDetailsDialog
			:command="state.nodeEditCommand"
			:node="state.nodeEditModel"
			:aspects="state.nodeEditAspects"
			@save="handleSaveNodeProperties"
		/>

		<WebContentEditorDialog
			:content="state.webContent"
			:command="state.webContentCommand"
			:title="state.nodeEditModel.title"
			@save="handleSaveWebContent"
		/>

		<CodeEditorDialog
			:content="state.codeContent"
			:command="state.codeCommand"
			:node="state.nodeEditModel"
			@save="handleSaveCodeContent"
		/>

		<div
			id="contextMenuWrapper"
			class="dropdown"
			style="position: fixed; z-index: 100"
		>
			<button
				class="invisible"
				id="contextMenuButton"
				type="button"
				data-bs-toggle="dropdown"
				aria-expanded="false"
			/>

			<ul class="dropdown-menu" aria-labelledby="menuButton">
				<li v-for="item in state.contextItems">
					<hr v-if="item.separator" class="dropdown-divider" />
					<a v-else class="dropdown-item" href="#" @click="item.cb">
						{{ item.title }}</a
					>
				</li>
			</ul>
		</div>

		<div class="d-none">
			<input ref="fileUploadRef" type="file" multiple @change="handleFileUpload" />
		</div>
	</div>
</template>

<style lang="scss" scoped>
$icon-width: 96px;
$icon-margin: 12px;

.discovery {
	font-size: 13px;
}

.discovery__header {
	height: 64px;
}

.discovery__main {
	display: flex;
	flex-wrap: nowrap;
}

.discovery__content {
	flex: 1 1 auto;
	padding: 1rem;
}

.discovery__toolbar {
	margin-bottom: 1em;

	display: flex;
	align-items: flex-end;
}

.content-header-separator {
	margin-right: 0.5em;
	margin-left: 0.5em;
	width: 2px;
	height: 1em;
	border-right: 1px solid var(--bluegray-200);
}

.breadcrumb {
	display: flex;
	align-items: center;
	color: #303030;
	font-size: 15px;
}

.breadcrumb > span {
	margin-right: 0.5em;
}

.breadcrumb:hover {
	cursor: pointer;
}

.discovery__details {
	box-sizing: border-box;
	flex: 0 0 256px;
}

.discovery__details > div {
	width: 100%;
	min-height: calc(100vh - 64px);
}

.dropdown-menu {
	font-size: 13px;
}
</style>
