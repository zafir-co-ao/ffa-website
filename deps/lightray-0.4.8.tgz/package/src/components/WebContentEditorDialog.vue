<script lang="ts">
import { WebContent } from "antbox";
import { onMounted, ref, watch } from "vue";
import HtmlEditor from "./HtmlEditor.vue";
</script>

<script lang="ts" setup>
export type WebContentEditorCommand = "show" | "hide" | "none";

export interface WebContentEditorProps {
	title?: string;
	command: WebContentEditorCommand;
	content: WebContent;
}

export interface WebContentEditorEvents {
	(e: "save", content: WebContent): void;
	(e: "update:command", command: WebContentEditorCommand): void;
}
const props = defineProps<WebContentEditorProps>();
const emit = defineEmits<WebContentEditorEvents>();

const curcontent = ref("");
const curlang = ref("pt");
const content = ref<Record<string, string>>();
const modalRef = ref();
const dialogRef = ref();

watch(
	() => props.content,
	() => {
		content.value = props.content as unknown as Record<string, string>;
		curcontent.value = content.value.pt;
		curlang.value = "pt";
	},
);

watch(
	() => props.command,
	(command) => {
		if (command === "show") {
			modalRef.value.show();
			emit("update:command", "none");
		} else if (command === "hide") {
			modalRef.value.hide();
		}
	},
);

onMounted(() => {
	const Modal = (window as any).bootstrap.Modal;
	modalRef.value = new Modal(dialogRef.value);
});

function changeLanguage(lang: string) {
	if (content.value) {
		if (!content.value[lang]) {
			content.value[lang] = "";
		}

		content.value[curlang.value] = curcontent.value;
		curcontent.value = content.value[lang];
		curlang.value = lang;
	}
}

function save() {
	if (content.value) {
		content.value[curlang.value] = curcontent.value;
	}

	emit("save", content.value as unknown as WebContent);
}
</script>

<template>
	<div ref="dialogRef" class="modal" tabindex="-1">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">{{ title ?? "" }}</h5>
					<button
						type="button"
						class="btn-close"
						data-bs-dismiss="modal"
						aria-label="Close"
					></button>
				</div>
				<div class="modal-body">
					<div class="mb-2 mt-4">
						<button
							role="button"
							class="btn btn-sm"
							:class="{
								'btn-primary': curlang === 'pt',
								'btn-secondary': curlang !== 'pt',
							}"
							@click="changeLanguage('pt')"
						>
							Português
						</button>
						&nbsp;
						<button
							role="button"
							class="btn btn-sm"
							:class="{
								'btn-primary': curlang === 'en',
								'btn-secondary': curlang !== 'en',
							}"
							@click="changeLanguage('en')"
						>
							Inglês
						</button>
					</div>
					<html-editor v-model="curcontent" />
				</div>

				<div class="modal-footer">
					<button type="button" class="btn" data-bs-dismiss="modal">
						Cancelar
					</button>
					<button type="button" class="btn btn-primary" @click="save">
						Gravar
					</button>
				</div>
			</div>
		</div>
	</div>
</template>
