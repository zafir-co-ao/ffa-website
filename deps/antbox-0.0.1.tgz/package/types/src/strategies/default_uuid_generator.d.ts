import { UuidGenerator } from "../ecm/uuid_generator.js";
export default class DefaultUuidGenerator implements UuidGenerator {
    private readonly charTable;
    constructor();
    generate(): string;
    private buildCharactersArray;
    private buildSmallCasesArray;
    private buildUpperCasesArray;
    private buildNumbersArray;
    private generateUnicodeArrayFromCodePoint;
    private generateUnicodeArray;
    private generateSafiraIdCharacters;
}
