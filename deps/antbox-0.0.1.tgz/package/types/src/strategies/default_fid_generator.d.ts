import { FidGenerator } from "../ecm/fid_generator.js";
export default class DefaultFidGenerator implements FidGenerator {
    generate(title: string): string;
}
