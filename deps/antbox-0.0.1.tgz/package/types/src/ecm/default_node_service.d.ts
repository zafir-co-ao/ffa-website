import * as denoShim from "deno.ns";
import { NodeFilterResult, NodeService, NodeServiceContext, SmartFolderNodeEvaluation } from "./node_service.js";
import { Node, NodeFilter } from "./node.js";
import { RequestContext } from "./request_context.js";
export default class DefaultNodeService implements NodeService {
    private readonly context;
    constructor(context: NodeServiceContext);
    createFile(request: RequestContext, file: denoShim.File, parent?: string): Promise<string>;
    createFolder(request: RequestContext, title: string, parent?: string): Promise<string>;
    private isRootFolder;
    private createFileMetadata;
    private createFolderMetadata;
    copy(request: RequestContext, uuid: string): Promise<string>;
    updateFile(request: RequestContext, uuid: string, file: denoShim.File): Promise<void>;
    delete(request: RequestContext, uuid: string): Promise<void>;
    get(_request: RequestContext, uuid: string): Promise<Node>;
    private getFromRepository;
    list(_request: RequestContext, parent?: string): Promise<Node[]>;
    query(_request: RequestContext, constraints: NodeFilter[], pageSize?: number, pageToken?: number): Promise<NodeFilterResult>;
    update(request: RequestContext, uuid: string, data: Partial<Node>): Promise<void>;
    evaluate(_request: RequestContext, uuid: string): Promise<SmartFolderNodeEvaluation>;
    private appendAggregations;
    private hasAggregations;
    private isSmartFolderNode;
    private isFolderNode;
    private isFileNode;
    export(request: RequestContext, uuid: string): Promise<denoShim.Blob>;
}
