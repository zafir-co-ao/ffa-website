import EngineError from "./engine_error.js";
export default class SmartFolderNodeNotFoundError extends EngineError {
    static ERROR_CODE: string;
    constructor(uuid: string);
}
