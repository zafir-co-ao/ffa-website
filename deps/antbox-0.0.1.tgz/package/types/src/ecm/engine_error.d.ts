export default class EngineError {
    readonly errorCode: string;
    readonly message: string;
    constructor(errorCode: string, message: string);
}
