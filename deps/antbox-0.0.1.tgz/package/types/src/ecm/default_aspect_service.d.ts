import { AspectService, AspectServiceContext } from "./aspect_service.js";
import { Aspect } from "./aspect.js";
import { RequestContext } from "./request_context.js";
export default class DefaultAspectService implements AspectService {
    private readonly context;
    constructor(context: AspectServiceContext);
    create(_request: RequestContext, aspect: Aspect): Promise<void>;
    update(request: RequestContext, uuid: string, aspect: Aspect): Promise<void>;
    private validateAspect;
    delete(_request: RequestContext, uuid: string): Promise<void>;
    get(_request: RequestContext, uuid: string): Promise<Aspect>;
    list(): Promise<Aspect[]>;
}
