export declare const FOLDER_MIMETYPE = "application/folder";
export declare const SMART_FOLDER_MIMETYPE = "application/smartfolder";
export declare const ROOT_FOLDER_UUID = "ROOT";
export declare type Properties = Record<string, unknown>;
export interface Node extends Record<string, unknown> {
    uuid: string;
    fid: string;
    title: string;
    description?: string;
    mimetype: string;
    size: number;
    starred: boolean;
    trashed: boolean;
    aspects?: string[];
    parent?: string;
    createdTime: string;
    modifiedTime: string;
    owner: string;
    properties?: Properties;
}
export interface FolderNode extends Node {
    onCreate: string[];
    onUpdate: string[];
}
export interface FileNode extends Node {
    versions: string[];
}
export interface SmartFolderNode extends Node {
    aspectConstraints: [string];
    mimetypeConstraints: [string];
    filters: NodeFilter[];
    aggregations?: Aggregation[];
}
export declare type FilterOperator = "==" | "<=" | ">=" | "<" | ">" | "!=" | "in" | "not-in" | "array-contains" | "array-contains-any";
export declare type NodeFilter = [
    field: string,
    operator: FilterOperator,
    value: unknown
];
export interface Aggregation {
    title: string;
    fieldName: string;
    formula: AggregationFormula;
}
export declare type AggregationFormula = "sum" | "count" | "avg" | "med" | "max" | "min" | "string";
export declare function isFid(uuid: string): boolean;
export declare function uuidToFid(fid: string): string;
export declare function fidToUuid(fid: string): string;
