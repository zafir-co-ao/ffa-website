import EngineError from "./engine_error.js";
export default class FolderNotFoundError extends EngineError {
    static ERROR_CODE: string;
    constructor(uuid: string);
}
