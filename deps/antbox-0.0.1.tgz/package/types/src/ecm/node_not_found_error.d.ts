import EngineError from "./engine_error.js";
export default class NodeNotFoundError extends EngineError {
    static ERROR_CODE: string;
    constructor(uuid: string);
}
