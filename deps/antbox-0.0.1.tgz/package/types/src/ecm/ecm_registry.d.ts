import { AspectService, AspectServiceContext } from "./aspect_service.js";
import { NodeServiceContext } from "./node_service.js";
import { NodeService } from "./node_service.js";
export interface EcmConfig {
    readonly nodeServiceContext: NodeServiceContext;
    readonly aspectServiceContext: AspectServiceContext;
}
export default class EcmRegistry {
    private static _instance;
    static get instance(): EcmRegistry;
    static buildIfNone(ecmConfig: EcmConfig): EcmRegistry;
    static build(ecmConfig: EcmConfig): EcmRegistry;
    constructor(config: EcmConfig);
    readonly nodeService: NodeService;
    readonly aspectService: AspectService;
}
