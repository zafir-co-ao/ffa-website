import AspectService, { AspectServiceContext } from "./aspects/aspect_service.js";
import NodeService, { NodeServiceContext } from "./nodes/node_service.js";
export interface EcmConfig {
    readonly nodeServiceContext: NodeServiceContext;
    readonly aspectServiceContext: AspectServiceContext;
}
export default class EcmRegistry {
    private static _instance;
    static get instance(): EcmRegistry;
    static buildIfNone(ecmConfig: EcmConfig): EcmRegistry;
    static build(ecmConfig: EcmConfig): EcmRegistry;
    constructor(config: EcmConfig);
    readonly nodeService: NodeService;
    readonly aspectService: AspectService;
}
