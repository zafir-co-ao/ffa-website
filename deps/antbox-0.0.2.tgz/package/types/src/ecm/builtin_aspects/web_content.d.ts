export interface WebContent {
    pt: string;
    en?: string;
    es?: string;
    fr?: string;
}
declare const _default: {
    uuid: string;
    title: string;
    builtIn: boolean;
    description: string;
    mimetypeConstraints: string[];
    properties: never[];
};
export default _default;
