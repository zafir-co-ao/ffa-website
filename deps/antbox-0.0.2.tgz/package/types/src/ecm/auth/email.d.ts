import EcmError from "../ecm_error.js";
import Either from "../../helpers/either.js";
export default class Email {
    readonly value: string;
    static make(value: string): Either<Email, EcmError>;
    private constructor();
}
