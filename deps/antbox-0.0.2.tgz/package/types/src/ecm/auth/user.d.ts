import Email from "./email.js";
import Fullname from "./fullname.js";
import Password from "./password.js";
export default class User {
    readonly email: Email;
    private _fullname;
    private _password;
    get fullname(): Fullname;
    get password(): Password;
    constructor(email: Email, fullname: Fullname, password: Password);
}
