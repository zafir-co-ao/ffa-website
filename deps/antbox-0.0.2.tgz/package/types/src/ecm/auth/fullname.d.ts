import EcmError from "../ecm_error.js";
import Either from "../../helpers/either.js";
export default class Fullname {
    readonly value: string;
    static make(value: string): Either<Fullname, EcmError>;
    private constructor();
}
