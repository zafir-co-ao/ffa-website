import PasswordGenerator from "./password_generator.js";
import EmailSender from "./email_sender.js";
import EcmError from "../ecm_error.js";
import Either from "../../helpers/either.js";
import UserRepository from "./user_repository.js";
export interface AuthServiceContext {
    passwordGenerator: PasswordGenerator;
    emailSender: EmailSender;
    userRepository: UserRepository;
}
export default class AuthService {
    private readonly ctx;
    constructor(ctx: AuthServiceContext);
    createUser(email: string, fullname: string): Either<void, EcmError>;
}
