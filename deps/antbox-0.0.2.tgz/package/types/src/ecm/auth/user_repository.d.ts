import EcmError from "../ecm_error.js";
import User from "./user.js";
import Either from "../../helpers/either.js";
export default interface UserRepository {
    addOrReplace(user: User): Promise<Either<void, EcmError>>;
}
