import Either from "../../helpers/either.js";
import EcmError from "../ecm_error.js";
export default class Password {
    static make(value: string): Either<Password, EcmError>;
    readonly digestedPassword: string;
    private constructor();
}
