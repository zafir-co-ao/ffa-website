import Email from "./email.js";
import Fullname from "./fullname.js";
export default interface EmailSender {
    send(email: Email, fullname: Fullname, password: string): void;
}
