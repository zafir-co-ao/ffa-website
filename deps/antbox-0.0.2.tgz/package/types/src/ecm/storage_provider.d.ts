import * as denoShim from "deno.ns";
export interface StorageProvider {
    delete(uuid: string): Promise<void>;
    write(uuid: string, file: denoShim.Blob): Promise<void>;
    read(uuid: string): Promise<denoShim.Blob>;
}
