import EcmError from "../ecm_error.js";
export default class InvalidNodeToCopyError implements EcmError {
    static ERROR_CODE: string;
    readonly errorCode: string;
    readonly message: string;
    constructor(uuid: string);
}
