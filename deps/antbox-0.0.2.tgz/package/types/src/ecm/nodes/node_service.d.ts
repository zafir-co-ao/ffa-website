import * as denoShim from "deno.ns";
import { RequestContext } from "../request_context.js";
import { Node, NodeFilter } from "./node.js";
import { FidGenerator } from "./fid_generator.js";
import { NodeRepository } from "./node_repository.js";
import { StorageProvider } from "../storage_provider.js";
import { UuidGenerator } from "./uuid_generator.js";
export interface NodeServiceContext {
    readonly fidGenerator?: FidGenerator;
    readonly uuidGenerator?: UuidGenerator;
    readonly storage: StorageProvider;
    readonly repository: NodeRepository;
}
export default class NodeService {
    private readonly context;
    constructor(context: NodeServiceContext);
    createFile(request: RequestContext, file: denoShim.File, parent?: string): Promise<string>;
    createFolder(request: RequestContext, title: string, parent?: string): Promise<string>;
    private isRootFolder;
    private createFileMetadata;
    private createFolderMetadata;
    copy(request: RequestContext, uuid: string): Promise<string>;
    updateFile(request: RequestContext, uuid: string, file: denoShim.File): Promise<void>;
    delete(request: RequestContext, uuid: string): Promise<void>;
    get(_request: RequestContext, uuid: string): Promise<Node>;
    private getFromRepository;
    list(_request: RequestContext, parent?: string): Promise<Node[]>;
    query(_request: RequestContext, constraints: NodeFilter[], pageSize?: number, pageToken?: number): Promise<NodeFilterResult>;
    update(request: RequestContext, uuid: string, data: Partial<Node>): Promise<void>;
    evaluate(_request: RequestContext, uuid: string): Promise<SmartFolderNodeEvaluation>;
    private appendAggregations;
    private hasAggregations;
    private isSmartFolderNode;
    private isFolderNode;
    private isFileNode;
    export(request: RequestContext, uuid: string): Promise<denoShim.Blob>;
}
export interface SmartFolderNodeEvaluation {
    records: Record<string, unknown>[];
    aggregations?: {
        title: string;
        value: unknown;
    }[];
}
export interface NodeFilterResult {
    pageToken: number;
    pageSize: number;
    pageCount: number;
    nodes: Array<Node>;
}
