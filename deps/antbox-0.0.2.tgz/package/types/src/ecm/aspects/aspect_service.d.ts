import { Aspect } from "./aspect.js";
import { AspectRepository } from "./aspect_repository.js";
import AuthService from "../auth/auth_service.js";
import { RequestContext } from "../request_context.js";
export interface AspectServiceContext {
    readonly auth?: AuthService;
    readonly repository: AspectRepository;
}
export default class AspectService {
    private readonly context;
    constructor(context: AspectServiceContext);
    create(_request: RequestContext, aspect: Aspect): Promise<void>;
    update(request: RequestContext, uuid: string, aspect: Aspect): Promise<void>;
    private validateAspect;
    delete(_request: RequestContext, uuid: string): Promise<void>;
    get(_request: RequestContext, uuid: string): Promise<Aspect>;
    list(_request: RequestContext): Promise<Aspect[]>;
}
