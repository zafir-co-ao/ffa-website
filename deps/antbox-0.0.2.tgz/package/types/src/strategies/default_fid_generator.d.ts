import { FidGenerator } from "../ecm/nodes/fid_generator.js";
export default class DefaultFidGenerator implements FidGenerator {
    generate(title: string): string;
}
