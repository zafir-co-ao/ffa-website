export default interface Either<S, E> {
    success?: S;
    alt?: S;
    error?: E;
}
export declare function success<S, E>(success: S): Either<S, E>;
export declare function error<S, E>(error: E, alt?: S): Either<S, E>;
