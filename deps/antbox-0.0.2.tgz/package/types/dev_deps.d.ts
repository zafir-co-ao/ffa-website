export { assertEquals, assertStrictEquals, } from "./deps/deno_land_std_0_123_0/testing/asserts.js";
export * as belike from "./test/belike.js";
