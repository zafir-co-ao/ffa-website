declare function fn<T>(v: T): T & BelikerFn;
export interface BelikerFn {
    called(): boolean;
    calledTimes(v: number): boolean;
    calledWith(...args: any[]): boolean;
}
export { fn };
