<script lang="ts" setup>
import NodeIcon from "./NodeIcon.vue";

const props = defineProps({
	nodes: Object,
	isSelectedFn: { type: Function, required: true },
	title: String,
});
const emit = defineEmits(["select", "multipleSelect", "open", "context"]);
</script>

<template>
	<div
		class="nodes-renderer-section"
		:class="{ 'nodes-renderer-section--empty': !nodes || nodes.length === 0 }"
	>
		<div class="nodes-renderer-section__title fs-6 fw-bolder">{{ title }}</div>
		<div class="nodes-renderer-section__main">
			<NodeIcon
				v-for="node in nodes"
				:key="node.uuid"
				:node="node"
				:selected="isSelectedFn(node.uuid)"
				@multipleSelect="emit('multipleSelect', $event)"
				@select="emit('select', $event)"
				@open="emit('open', $event)"
				@context="emit('context', $event)"
			/>
		</div>
	</div>
</template>

<style lang="scss" scoped>
.nodes-renderer-section {
	margin-top: 2rem;
}

.nodes-renderer-section--empty .nodes-renderer-section__title {
	color: var(--bluegray-600);
	font-style: italic;
}

.nodes-renderer-section__main {
	display: flex;
	flex-wrap: wrap;
	justify-content: stretch;
	box-sizing: border-box;
}
</style>
