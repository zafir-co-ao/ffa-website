<script lang="ts" setup>
import Discovery from "~lightray/Discovery.vue";
import { aspectServiceClient, nodeServiceClient } from "~~/lib/deps";

const url = useAntboxClient();

definePageMeta({ layout: "admin" });
</script>

<template>
	<div>
		<ClientOnly>
			<Discovery :antbox-url="url" />
		</ClientOnly>
	</div>
</template>
